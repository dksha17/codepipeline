#!/bin/bash


service httpd stop

rm /var/www/html/index.html