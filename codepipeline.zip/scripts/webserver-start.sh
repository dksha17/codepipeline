#!/bin/bash


service httpd start
